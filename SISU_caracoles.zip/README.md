# caracoles
El mejor lugar para apostar por tu caracol favorito en carreras de caracoles.




# Prueba 1 - UX

Se adjuntan wireframes de baja y alta fidelidad para aterrizar la idea del producto.

Ruta: pruebas/UX
Tiempo de elaboración: ~6 hrs

# Prueba 1.5 - Gráfico

Se adjunta propuesta como planteamiento principal del producto en mobile y desktop

Ruta: pruebas/grafico
Tiempo de elaboración: ~5 hrs

# Prueba 2 - Implementación

Se adjuntan archivos html y css con las vistas del prototipo previamente creado.

Ruta: index.html, assets/
Tiempo de elaboración: ~8 hrs


# Anexo

Si alguno de los formatos no se visualizan correctamente, o requiere ver el flujo de navegación, dejaré el link del draft desde figma, así como el repositorio del proyecto.

https://www.figma.com/file/kZC9BTcHCjbiiiEvtHsf5J/SnailRacing?node-id=61%3A2481

https://github.com/memorstx/caracoles



¡Saludos!



